# GOODLAB Weekly Report Tips

1. **直接描述工作内容即可** — 不需要整理成固定格式，说「本周做了XXX」「研究进展XXX」就能触发，Claude 会自动提炼成规范周报
2. **提供越多细节越好** — 说明遇到的问题、解决方法、具体数据和指标，第二节详情会更有技术深度
3. **PDF 生成需要 TeX Live** — 若未安装，macOS 执行 `brew install --cask mactex`，Windows 访问 tug.org/texlive 下载；无 LaTeX 时仍可获得 latex.zip 上传 Overleaf 在线编译
4. **输出文件在桌面** — 生成的 `周报-YYYYMMDD/` 文件夹直接放在桌面，macOS 和 Windows 均自动适配路径
5. **修改周报内容** — 解压 latex.zip，用文本编辑器修改 `main.tex`，再执行两次 `xelatex main.tex` 重新编译；或直接上传到 overleaf.com 在线编辑
6. **修改作者和单位** — 在 `main.tex` 中找到 `\author{}` 部分，替换姓名和单位名称
7. **LaTeX 特殊字符要转义** — 百分号写 `\%`，下划线写 `\_`，&符号写 `\&`，否则编译报错
8. **下周计划可以指定** — 如果你有明确的下周计划，直接告诉 Claude；否则它会根据本周进展合理推断
