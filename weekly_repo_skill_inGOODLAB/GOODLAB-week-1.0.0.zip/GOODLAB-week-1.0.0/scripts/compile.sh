#!/usr/bin/env bash
# compile.sh — 编译 LaTeX 周报并打包为 latex.zip
# 用法: bash compile.sh <path/to/main.tex>
#
# 依赖: xelatex (TeX Live / MacTeX), zip
# 输出: 同目录下的 weekly_report.pdf 和 latex.zip

set -euo pipefail

# ——— 参数处理 ———
TEX_FILE="${1:-}"
if [[ -z "$TEX_FILE" ]]; then
    echo "[ERROR] 请提供 .tex 文件路径，例如: bash compile.sh /tmp/report/main.tex"
    exit 1
fi

TEX_FILE="$(realpath "$TEX_FILE")"
TEX_DIR="$(dirname "$TEX_FILE")"
TEX_NAME="$(basename "$TEX_FILE" .tex)"

# ——— 检查 xelatex ———
if ! command -v xelatex &>/dev/null; then
    echo "[WARN] xelatex 未找到，尝试使用 pdflatex（不支持中文，建议安装 TeX Live）"
    LATEX_CMD="pdflatex"
else
    LATEX_CMD="xelatex"
fi

echo "=========================================="
echo "  GOODLAB Weekly Report Compiler"
echo "  引擎: $LATEX_CMD"
echo "  源文件: $TEX_FILE"
echo "  输出目录: $TEX_DIR"
echo "=========================================="

# ——— 编译（两次，保证目录和引用正确）———
cd "$TEX_DIR"

echo "[1/2] 第一次编译..."
$LATEX_CMD -interaction=nonstopmode "$TEX_NAME.tex" > compile_1.log 2>&1 || true

echo "[2/2] 第二次编译（生成正确目录）..."
$LATEX_CMD -interaction=nonstopmode "$TEX_NAME.tex" > compile_2.log 2>&1 || true

# ——— 检查 PDF 是否生成 ———
PDF_FILE="$TEX_DIR/${TEX_NAME}.pdf"
if [[ -f "$PDF_FILE" ]]; then
    # 重命名为 weekly_report.pdf
    cp "$PDF_FILE" "$TEX_DIR/weekly_report.pdf"
    echo "[OK] PDF 已生成: $TEX_DIR/weekly_report.pdf"
else
    echo "[ERROR] PDF 生成失败，请查看 compile_2.log 排查错误"
    echo "常见原因: 缺少 LaTeX 包（运行 tlmgr install ctex）"
    exit 2
fi

# ——— 清理辅助文件，打包 zip ———
echo "[ZIP] 打包 LaTeX 源文件..."

# 要打包到 zip 的文件（源文件 + 生成的 PDF）
ZIP_INCLUDE=(
    "main.tex"
    "weekly_report.pdf"
)

# 如果有 images 目录也一起打包
if [[ -d "$TEX_DIR/images" ]]; then
    ZIP_INCLUDE+=("images/")
fi

cd "$TEX_DIR"
zip -r "latex.zip" "${ZIP_INCLUDE[@]}" 2>/dev/null || {
    # 如果指定文件不存在，退回打包所有 tex 相关文件
    zip -r "latex.zip" *.tex *.pdf images/ 2>/dev/null || zip -r "latex.zip" *.tex *.pdf 2>/dev/null || true
}

if [[ -f "$TEX_DIR/latex.zip" ]]; then
    echo "[OK] 源文件已打包: $TEX_DIR/latex.zip"
else
    echo "[WARN] zip 打包失败，请手动压缩 $TEX_DIR 目录"
fi

echo ""
echo "=========================================="
echo "  编译完成！"
echo "  PDF:      $TEX_DIR/weekly_report.pdf"
echo "  ZIP:      $TEX_DIR/latex.zip"
echo "  修改方式: 用文本编辑器打开 main.tex，"
echo "            修改后执行 xelatex main.tex 两次重新编译"
echo "  在线编辑: 将 latex.zip 上传至 overleaf.com"
echo "=========================================="
