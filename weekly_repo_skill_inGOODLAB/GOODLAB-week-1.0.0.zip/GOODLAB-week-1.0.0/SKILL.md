---
version: "1.0.0"
name: goodlab-week
description: "周报生成器：根据用户描述的工作内容，自动生成精美的LaTeX格式周报，包含「本周工作总结」「本周工作内容详情」「下周工作计划」三大章节，并输出可编辑的latex.zip源文件和编译好的PDF。当用户说「帮我写个周报」「周报」「写周报」「生成周报」「本周干了XXX」「这周做了XXX」「工作进展为XXX」「帮我整理一下本周工作」「本周学习了XXX」「研究进展XXX」，或者用户描述了任何本周的工作、学习、实验、研究内容时，必须立即调用此skill，不要只用文字回答，要生成LaTeX源文件和PDF。"
author: GOODLAB
---

# GOODLAB Weekly Report Generator

根据用户描述的本周工作，自动生成结构清晰、排版精美的 LaTeX 周报，产出两个文件：
- **`latex.zip`** — 含 `main.tex` 的可编辑源文件包
- **`weekly_report.pdf`** — 编译好的 PDF 周报

---

## 触发时机

只要用户：
- 说出「周报」「写周报」「帮我写个周报」「生成周报」等词
- 描述了本周的工作内容、研究进展、实验结果、学习情况
- 说「本周干了…」「这周做了…」「工作进展…」「本周学习了…」

就应当立刻执行本 skill，**不要只输出文字，必须生成文件**。

---

## 工作流程

### 第一步：提取关键信息

从用户输入中识别以下信息（缺失时使用括号内默认值）：

| 字段 | 来源 | 默认值 |
|------|------|--------|
| 姓名 | 用户输入 | Jin Zhao |
| 单位第一行 | 用户输入 | Nanchang University |
| 单位第二行 | 用户输入 | School of Artificial Intelligence |
| 单位第三行 | 用户输入 | Generic Operational and Optimal Data Group |
| 本周工作事项 | 用户输入 | 必须从用户描述中提取 |
| 遇到的问题及解决方案 | 用户输入或推断 | 根据工作内容合理推断 |
| 收获与体会 | 用户输入或推断 | 根据工作内容合理推断 |
| 下周计划 | 用户输入或根据进展推断 | 根据本周进展合理规划 |

### 第二步：生成三段式周报内容

#### 第一节：本周工作总结（精炼条目式）

- 将本周所有工作浓缩成 **3~7 条**简洁条目
- 每条一句话，清晰点明做了什么、达成了什么
- LaTeX 使用 `\begin{itemize} \item ... \end{itemize}`
- 目标：让读者扫一眼就知道本周干了什么

**示例格式：**
```latex
\begin{itemize}
    \item 完成了XXX数据集的预处理与特征工程，共处理样本X条
    \item 复现了YYY论文的基线模型，在ZZZ指标上达到XX\%
    \item 调研并整理了AAA领域最新进展，阅读文献X篇
\end{itemize}
```

#### 第二节：本周工作内容详情（深度展开）

- 对每项工作进行详细说明，使用 `\subsection{}` 分小节
- 每个小节包含：**做了什么 → 遇到什么问题 → 如何解决 → 收获与体会**
- 语言专业、流畅，体现技术深度
- 如有数据、指标、方法名称，应明确写出

**子节结构模板：**
```latex
\subsection{XXX工作}
本周...（做了什么）。

在此过程中，遇到了...（问题描述）。经过...（解决过程），最终...（解决结果）。

通过本次工作，深入理解了...（收获）。
```

#### 第三节：下周工作计划（前瞻性条目式）

- 根据本周进展，规划 **3~5 条**下周任务
- 每条具体可执行，体现延续性和递进性
- LaTeX 使用 `\begin{itemize} \item ... \end{itemize}`

### 第三步：生成完整 LaTeX 文件

将内容填入以下模板，生成完整的 `main.tex`。**请直接使用 Write 工具写入文件，不要只在对话中展示**。

参考 `assets/template.tex` 中的 LaTeX 文档结构和 preamble。生成时，将 `%%AUTHOR%%`、`%%INSTITUTION_1%%`、`%%INSTITUTION_2%%`、`%%INSTITUTION_3%%`、`%%SECTION1%%`、`%%SECTION2%%`、`%%SECTION3%%` 替换为实际内容。

**输出目录（跨平台桌面路径）：**

在生成文件前，先用 Bash 检测操作系统并确定桌面路径：

```bash
# 自动检测桌面路径（macOS / Windows Git Bash / WSL 均适用）
if [[ "$OSTYPE" == "darwin"* ]]; then
    DESKTOP="$HOME/Desktop"
elif [[ "$OSTYPE" == "msys"* ]] || [[ "$OSTYPE" == "cygwin"* ]]; then
    # Git Bash / Cygwin on Windows
    DESKTOP="$(cygpath "$USERPROFILE/Desktop" 2>/dev/null || echo "$USERPROFILE/Desktop")"
elif grep -qi microsoft /proc/version 2>/dev/null; then
    # WSL (Windows Subsystem for Linux)
    WIN_USER="$(cmd.exe /c "echo %USERNAME%" 2>/dev/null | tr -d '\r')"
    DESKTOP="/mnt/c/Users/$WIN_USER/Desktop"
else
    DESKTOP="$HOME/Desktop"
fi
OUTPUT_DIR="$DESKTOP/周报-YYYYMMDD"
mkdir -p "$OUTPUT_DIR"
echo "输出目录: $OUTPUT_DIR"
```

将 `YYYYMMDD` 替换为今天的实际日期（如 `20260406`），最终输出到：
- **macOS**：`~/Desktop/周报-YYYYMMDD/`
- **Windows**：`C:\Users\用户名\Desktop\周报-YYYYMMDD\`（在 Git Bash / WSL 中等价路径）

### 第四步：编译 PDF

进入输出目录，执行以下内联编译命令（无需依赖 skill 路径）：

```bash
cd "$OUTPUT_DIR"

# 检查编译引擎
if command -v xelatex &>/dev/null; then
    LATEX_CMD="xelatex"
elif command -v pdflatex &>/dev/null; then
    LATEX_CMD="pdflatex"
    echo "[WARN] xelatex 未找到，使用 pdflatex（中文可能显示异常，建议安装 TeX Live）"
else
    echo "[ERROR] 未找到 LaTeX 编译器，请安装 TeX Live 后重试"
    echo "        macOS:   brew install --cask mactex"
    echo "        Windows: 下载 https://tug.org/texlive/"
    exit 1
fi

echo "[1/2] 第一次编译..."
$LATEX_CMD -interaction=nonstopmode main.tex > compile_1.log 2>&1 || true

echo "[2/2] 第二次编译（生成正确目录）..."
$LATEX_CMD -interaction=nonstopmode main.tex > compile_2.log 2>&1 || true

# 重命名 PDF
if [[ -f "main.pdf" ]]; then
    cp main.pdf weekly_report.pdf
    echo "[OK] PDF 已生成: $OUTPUT_DIR/weekly_report.pdf"
else
    echo "[WARN] PDF 生成失败，请查看 compile_2.log"
    echo "       常见原因：缺少 ctex 包（运行 tlmgr install ctex）"
fi

# 打包 zip（含源文件 + PDF）
zip -r latex.zip main.tex weekly_report.pdf 2>/dev/null || \
    zip -r latex.zip main.tex 2>/dev/null || true
[[ -f "latex.zip" ]] && echo "[OK] 源文件已打包: $OUTPUT_DIR/latex.zip"
```

### 第五步：交付结果

向用户说明：
1. **PDF 位置**：`$OUTPUT_DIR/weekly_report.pdf`（即桌面的 `周报-YYYYMMDD` 文件夹）
   - macOS：`~/Desktop/周报-YYYYMMDD/weekly_report.pdf`
   - Windows：`C:\Users\用户名\Desktop\周报-YYYYMMDD\weekly_report.pdf`
2. **可编辑 ZIP**：`$OUTPUT_DIR/latex.zip`（含 `main.tex`，可用 Overleaf 或本地 LaTeX 环境修改）
3. 简要说明如何自定义（修改作者、机构、内容等）

---

## 内容质量要求

- **第一节**：精炼，每条 ≤ 30 字，一目了然
- **第二节**：丰富，每个子节 ≥ 100 字，有技术深度
- **第三节**：具体，每条计划有明确的行动指向
- **整体**：语言流畅自然，专业但不晦涩，体现研究生/工程师的专业素养
- **LaTeX**：特殊字符（`%`, `&`, `_`, `#`, `$`, `{`, `}`）需正确转义

---

## 常见 LaTeX 转义规则

| 字符 | LaTeX 写法 |
|------|-----------|
| % | `\%` |
| & | `\&` |
| _ | `\_` |
| # | `\#` |
| $ | `\$` |
| { } | `\{ \}` |
| ~ | `\textasciitilde{}` |
| ^ | `\textasciicircum{}` |

---

## 参考资源

- `assets/template.tex` — LaTeX 模板（preamble、文档结构、样式定义）
- `scripts/compile.sh` — 自动编译脚本（xelatex + zip 打包）
