# GOODLAB Weekly Report Tips

1. **直接描述工作内容即可** — 不需要整理成固定格式，说「本周做了XXX」「研究进展XXX」就能触发，Claude 会自动提炼成规范周报
2. **提供越多细节越好** — 说明遇到的问题、解决方法、具体数据和指标，第二节详情会更有技术深度
3. **零依赖，无需安装任何软件** — 只生成一个 .md 文件，用记事本、VS Code、Typora 等任意编辑器均可打开
4. **输出文件在桌面** — 生成的 `周报-YYYYMMDD.md` 直接放在桌面，macOS 和 Windows 均自动适配路径
5. **修改周报内容** — 用任意文本编辑器打开 .md 文件直接编辑即可，格式简单清晰
6. **指定作者和单位** — 告诉 Claude 你的姓名和单位，否则默认使用 Jin Zhao / Nanchang University
7. **下周计划可以指定** — 如果你有明确的下周计划，直接告诉 Claude；否则它会根据本周进展合理推断
8. **Markdown 预览** — VS Code 按 Ctrl+Shift+V（Windows）或 Cmd+Shift+V（macOS）可实时预览排版效果
