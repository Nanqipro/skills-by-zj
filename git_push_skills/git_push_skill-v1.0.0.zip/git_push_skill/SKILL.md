---
name: git-sync
description: Sync local git repositories to remote (GitHub). Use this skill whenever the user mentions syncing code, uploading code, pushing to GitHub, pulling from remote, or says things like "帮我同步一下", "上传代码", "push 一下", "sync my repos", "sync all repos", "push changes", "update remote". Triggers on any combination of git/push/pull/sync/upload/GitHub keywords. If the user names a specific repo, sync only that one; otherwise sync all repos under /Users/nanpipro/Documents/gitlocal.
---

# git-sync

Automates syncing one or all local git repositories to their remote counterparts by running `git pull`, `git add .`, `git commit`, and `git push` in sequence.

## Scope

All local repositories live under `/Users/nanpipro/Documents/gitlocal`. Each direct subdirectory of that folder is treated as one independent repository. Do NOT touch anything outside of `/Users/nanpipro/Documents/gitlocal`. Do NOT install, download, or modify any system configuration.

## Determine target repos

1. If the user named a specific repository (e.g. "sync skills-by-zj", "push my-project"), locate that folder under `/Users/nanpipro/Documents/gitlocal/<repo-name>`. If the folder does not exist, tell the user and stop.
2. If the user said "all", gave no repo name, or asked to sync everything, collect every direct subdirectory of `/Users/nanpipro/Documents/gitlocal` that contains a `.git` folder.

Use the Bash tool to discover repos:
```bash
ls -d /Users/nanpipro/Documents/gitlocal/*/
```

Then filter to only those that are git repos:
```bash
for d in /Users/nanpipro/Documents/gitlocal/*/; do
  [ -d "$d/.git" ] && echo "$d"
done
```

## Sync sequence (per repo)

Run these four commands **sequentially** inside each repo directory. Use a single Bash tool call per repo to keep output clean:

```bash
cd /Users/nanpipro/Documents/gitlocal/<repo-name> && \
git pull && \
git add . && \
git commit -m "$(date '+%Y-%m-%d')" && \
git push
```

**Important notes:**
- The commit message is the current date in `YYYY-MM-DD` format.
- `git commit` exits with code 1 when there is nothing to commit. Treat this as a **success** (repo is already up to date), not a failure. You can detect this by checking if the output contains "nothing to commit" or "nothing added to commit".
- Any other non-zero exit code (from pull, add, commit, or push) is a **failure**. Do not attempt to fix it automatically. Record it and continue to the next repo.

## Error handling

- When a command fails, capture the exact error output.
- Do not retry, do not force-push, do not resolve conflicts, do not rebase. Just record the failure and move on.
- If `git pull` fails (e.g. merge conflict, diverged branches), skip the remaining steps for that repo entirely and mark it failed.

## Post-sync report

After processing all repos, output a clear summary in this format:

```
## Sync Report — YYYY-MM-DD HH:MM

### Synced successfully
- repo-name-1
- repo-name-2 (nothing to commit, already up to date)

### Failed — action required
- repo-name-3
  Error: [paste the exact error output here]
- repo-name-4
  Error: [paste the exact error output here]
```

If everything succeeded, say so clearly. If anything failed, remind the user to check those repos manually.

## What not to do

- Do not modify any files outside `/Users/nanpipro/Documents/gitlocal`.
- Do not install any tools or packages.
- Do not change git config, SSH config, or any system settings.
- Do not make decisions about merge conflicts or diverged branches — report them to the user.
- Do not use `--force` or any destructive git flags.
